import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class bouncing_ball extends PApplet {

float ballx = 10;
float bally = 10;
float ballx1 = 50;
float bally1 = 70;
float ballx2 = 170;
float bally2 = 150;
int score=0;
int gameOver=-1;
int ball=0;
int ball1=0;
int ball2=0;
int c;
float x=random(1,10);
float y=random(1,10);
float x1=random(1,10);
float y1=random(1,10);
float x2=random(1,10);
float y2=random(1,10);

PImage bg;
public void setup()
{
  
  bg=loadImage("image3.jpg");
}
public void draw() 
{
 background(bg);
 if(gameOver==1)
  {
    gameisOver();
  }
 if(gameOver==-1)
  {
    textSize(24);
    text("Click to Start",180,230);
  }
 if(gameOver==0)
  { 
   background(bg);
  ellipse(ballx, bally, 20, 20);
  ellipse(ballx1, bally1, 20, 20);
  ellipse(ballx2, bally2, 20, 20);
  rect(mouseX,480,150,20);
  if(ball==1)
  {
   if(bally<520)
    {
     ballx=ballx+x;
     bally=bally+y;
    }
  }
  else 
  {
    ballx=ballx+x;
    bally=bally+y;
  }
  if(ball1==1)
  {
   if(bally1<520)
    {
     ballx1=ballx1+x1;
     bally1=bally1+y1;
    }
  }
  else 
  {
    ballx1=ballx1+x1;
    bally1=bally1+y1;
  }
  if(ball2==1)
  {
   if(bally2<520)
    {
     ballx2=ballx2+x2;
     bally2=bally2+y2;
    }
  }
  else 
  {
    ballx2=ballx2+x2;
    bally2=bally2+y2;
  }
  if(ballx>500|ballx<0)
   {
    x=-x;
    }
   if(ballx1>500|ballx1<0)
   {
    x1=-x1;
   }
   if(ballx2>500|ballx2<0)
   {
    x2=-x2;
   }
  
  if(bally<0)
   {
     y=-y;
   }
    if(bally1<0)
   {
     y1=-y1;
   }
    if(bally2<0)
   {
     y2=-y2;
   }
   
   if(bally>480&&ball==0)
   {
     if(ballx>mouseX&&ballx<mouseX+150)
      {
        y=-y;
        if(ball1==1&&ball2==1)
        {
        score++;
        }
        else if(ball1==0&&ball2==0)
        {
        score=score+3;
        }
        else
        {
        score=score+2;
        }
      }
     else
     {
      if(ball1==1&&ball2==1)
      {
        gameisOver();
      }
      else 
      {
       ball=1;
      
      }
     }
   }
   if(bally1>480&&ball1==0)
   {
     if(ballx1>mouseX&&ballx1<mouseX+150)
      {
        
        y1=-y1;
        if(ball==1&&ball2==1)
        {
        score++;
        }
        else if(ball==0&&ball2==0)
        {
        score=score+3;
        }
        else
        {
        score=score+2;
        }
      }
     else
     {
     if(ball==1&&ball2==1)
      {
       gameisOver();
      }
      else 
      {
       ball1=1;
      }
     }
   }
   if(bally2>480&&ball2==0)
   {
     if(ballx2>mouseX&&ballx2<mouseX+150)
      {
        y2=-y2;
        if(ball1==1&&ball==1)
        {
        score++;
        }
        else if(ball1==0&&ball==0)
        {
        score=score+3;
        }
        else
        {
        score=score+2;
        }
      }
     else
     {
      if(ball==1&&ball1==1)
      {
       gameisOver();
      }
      else 
      {
       ball2=1;
      }
     }
   }
   text("SCORE:"+score+"00",380,30);
   textSize(18);
  
  }
  
}
public void gameisOver()
{
 background(bg);
 textSize(20);
 text("Game Over",200,180);
 text("Click to Restart",185,240);
 text("SCORE:"+score+"00",200,210);
 gameOver=1;
}
public void mouseClicked()
{
  ballx = 10;
  bally = 10;
  ballx1 = 30;
  bally1 = 70;
  ballx2 = 170;
  bally2 = 150;
  score=0;
  gameOver=0;
  ball=0;
  ball1=0;
  ball2=0;
}
public void keyPressed() 
{
  if (key == CODED)
  {
    if (keyCode == RIGHT) 
    {
      if(mouseX<400)
      {
       mouseX=mouseX+40;
      }
    } 
    else if (keyCode ==LEFT)
    {
      if(mouseX>0)
      {
      mouseX=mouseX-40;
      }
    }
    else
    {
    }
  }
  
}
  public void settings() {  size(500, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "bouncing_ball" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
