import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class bouncing_ball2 extends PApplet {

float ballx = 20;
float bally = 20;
float ballx1 = 100;
float bally1 = 150;
float ballx2 = 150;
float bally2 = 150;
int score=0;
int gameOver=0;
int ball1=0;
int ball2=0;
int ball3=0;

float x=random(1,10);
float y=random(1,10);
float x1=random(1,10);
float y1=random(1,10);
float x2=random(1,10);
float y2=random(1,10);
public void setup()
{
  size(500, 500);
}
public void draw() 
{
 if(gameOver==0)
  { 
  background(0,20,0);
  ellipse(ballx, bally, 20, 20);
  ellipse(ballx1, bally1, 20, 20);
  ellipse(ballx2, bally2, 20, 20);
  rect(mouseX,480,150,20);
  if(ball1==1)
  {
   if(bally<520)
    {
     ballx=ballx+x;
     bally=bally+y;
    }
  }
  else 
  {
    ballx=ballx+x;
    bally=bally+y;
  }
  if(ball2==1)
  {
   if(bally1<520)
    {
     ballx1=ballx1+x1;
     bally1=bally1+y1;
    }
  }
  else 
  {
    ballx1=ballx1+x1;
    bally1=bally1+y1;
  }
  if(ball3==1)
  {
   if(bally2<520)
    {
     ballx2=ballx2+x2;
     bally2=bally2+y2;
    }
  }
  else 
  {
    ballx2=ballx2+x2;
    bally2=bally2+y2;
  }
  if(ballx>500|ballx<0)
   {
    x=-x;
    }
   if(ballx1>500|ballx1<0)
   {
    x1=-x1;
   }
   if(ballx2>500|ballx2<0)
   {
    x2=-x2;
   }
  
  if(bally<0)
   {
     y=-y;
   }
    if(bally1<0)
   {
     y1=-y1;
   }
    if(bally2<0)
   {
     y2=-y2;
   }
   
   if(bally>480&&ball1==0)
   {
     if(ballx>mouseX&&ballx<mouseX+150)
      {
        y=-y;
        if(ball2==1&&ball3==1)
        {
        score++;
        }
        else if(ball2==0&&ball3==0)
        {
        score=score+3;
        }
        else
        {
        score=score+2;
        }
      }
     else
     {
      if(ball2==1&&ball3==1)
      {
        gameisOver();
      }
      else 
      {
       ball1=1;
      
      }
     }
   }
   if(bally1>480&&ball2==0)
   {
     if(ballx1>mouseX&&ballx1<mouseX+150)
      {
        
        y1=-y1;
        if(ball1==1&&ball3==1)
        {
        score++;
        }
        else if(ball1==0&&ball3==0)
        {
        score=score+3;
        }
        else
        {
        score=score+2;
        }
      }
     else
     {
     if(ball1==1&&ball3==1)
      {
       gameisOver();
      }
      else 
      {
       ball2=1;
      }
     }
   }
   if(bally2>480&&ball3==0)
   {
     if(ballx2>mouseX&&ballx2<mouseX+150)
      {
        y2=-y2;
        if(ball2==1&&ball1==1)
        {
        score++;
        }
        else if(ball2==0&&ball1==0)
        {
        score=score+3;
        }
        else
        {
        score=score+2;
        }
      }
     else
     {
      if(ball1==1&&ball2==1)
      {
       gameisOver();
      }
      else 
      {
       ball3=1;
      }
     }
   }
  
  }
}
public void gameisOver()
{
 text("Game Over!",210,230);
 text("Click to Restart",210,270);
 text("SCORE:"+score+"00",210,250);
  gameOver=1;
}
public void mouseClicked()
{
  ballx = 20;
  bally = 20;
  ballx1 = 30;
  bally1 = 50;
  ballx2 = 100;
  bally2 = 150;
  score=0;
  gameOver=0;
  ball1=0;
  ball2=0;
  ball3=0;
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#F0F0F0", "bouncing_ball2" });
  }
}
